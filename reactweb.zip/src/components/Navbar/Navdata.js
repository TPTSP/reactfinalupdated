export const Navdata = [
	{ name: "HOME", link: "/" },
	{ name: "TEAM", link: "/team" },
	{ name: "ABOUT", link: "/" },
	{ name: "NEWS", link: "/news" },
	{ name: "CONTACT", link: "/" },
];
